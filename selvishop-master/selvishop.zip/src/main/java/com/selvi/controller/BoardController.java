package com.selvi.controller;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.log;

import javax.inject.Inject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.selvi.domain.BoardVO;
import com.selvi.service.BoardService;

@Controller
@RequestMapping("/board/*")
public class BoardController {
	
	private static final Logger logger=
			LoggerFactory.getLogger(BoardController.class);
	
	@Inject
	private BoardService service;
	
	@RequestMapping(value="/register", method=RequestMethod.GET)
	public void registerGET(BoardVO board,Model model) throws Exception{
		
		logger.info("registerGET() 호출 !!!!!");
	}

	@RequestMapping(value="/register", method=RequestMethod.POST)
	public String registerPOST(BoardVO board,RedirectAttributes rttr) throws Exception{
		logger.info("registerPOST() 호출 !!!!!");
		logger.info(board.toString());
		
		// 게시판 글쓰기 
		service.regist(board);
		
		//model.addAttribute("result","success");
		rttr.addFlashAttribute("result","success");
		
		//return "/board/success";
		// -> F5(새로고침)시 게시판 글쓰기 적용 
		//return "redirect:/board/success";
		return "redirect:/board/listAll";
	}
	
	// 게시판 목록 처리 메서드
	@RequestMapping(value="/listAll",method=RequestMethod.GET)
	public void listAll(Model model) throws Exception {
		
		logger.info("listAll() 호출 !!!!");
		
		// DB에서 게시판 목록을 읽어와서 출력
		// DB -> DAO -> Service -> Controller -> JSP 
		model.addAttribute("list",service.listAll());
		
	}
	
	// 게시글 정보를 확인(글번호)
	@RequestMapping(value="/read", method=RequestMethod.GET)
	public void read(@RequestParam("bno") int bno,Model model) throws Exception {
		
		// @RequestParam("bno") int bno
		// int bno =Integer.parseInt(request.getParameter("bno")) 와 유사하다.
		
		logger.info(" read() 메서드 호출 !!! ");

		// service 객체로부터 정보를 전달받아서 view(jsp) 페이지로 이동 
		BoardVO vo = service.read(bno);
		
		model.addAttribute("vo",vo);
		//model.addAttribute(vo);
	}
	
	// 게시판 글 수정(modify)
    @RequestMapping(value="/modify", method=RequestMethod.GET)	
	public void modifyGET(@RequestParam("bno") int bno,Model model) throws Exception{
		
    	logger.info("modifyGET() 호출 !!!");
    	
    	// BoardVO 객체 1개가 전달 (해당글번호)
    	//  전달받는 jsp페이지에서는 해당객체를 해당결과 타입을 변수로 사용
    	//  BoardVO객체 -> [boardVO.변수] 
    	model.addAttribute(service.read(bno));
    	
    	//model.addAttribute("bvo",service.read(bno));
    	// -> jsp 페이지에서 [bvo.변수]
	}
    
    @RequestMapping(value="/modify", method=RequestMethod.POST)
    public String modifyPOST(BoardVO board) throws Exception{
    	logger.info("modifyPOST() 메서드 호출 !!");
    	
    	// DB에 전달받은 board 객체의 정보를 수정 (update)
    	service.modify(board);
    	
    	// 페이지 이동 /board/listAll

    	return "redirect:/board/listAll";
    }
    
    // 삭제 
    @RequestMapping(value="/remove", method=RequestMethod.POST)
    public String remove(@RequestParam("bno") int bno,
    		              RedirectAttributes rttr) throws Exception{
    	
    	logger.info("remove() 호출 !!!");
    	
    	// 서비스 객체를 사용하여 삭제,(삭제할 글번호)  
    	service.remove(bno);
    	
    	// 성공정보를 확인 
    	// "result"변수에 "success"값을 저장후 페이지 이동 
    	rttr.addFlashAttribute("result", "success");
    	
    	// 페이지 이동 -> 전체 리스트 페이지로 이동 
    	return "redirect:/board/listAll";    	
    }
    
	
	
	
	
	
	
	
	
	
	
	
	
	

}
